#include <ros/ros.h>

#include <geometry_msgs/Pose.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>

ros::Publisher set_pose_pub;

void initialPoseCallback(const geometry_msgs::PoseWithCovarianceStamped& msg)
{
  ROS_INFO("receive initialpose: ");
  ROS_INFO("position(xyz): %.3f %.3f %.3f", msg.pose.pose.position.x
                                          , msg.pose.pose.position.y
                                          , msg.pose.pose.position.z);
  ROS_INFO("orientation(xyzw): %.3f %.3f %.3f %.3f", msg.pose.pose.orientation.x
                                                    , msg.pose.pose.orientation.y
                                                    , msg.pose.pose.orientation.z
                                                    , msg.pose.pose.orientation.w);
  geometry_msgs::Pose _pose_msg(msg.pose.pose);
  set_pose_pub.publish(_pose_msg);
}


int main (int argc, char **argv)
{

	ros::init(argc, argv, "set_initial_pose_demo");
  ros::NodeHandle nh("~");
  set_pose_pub = nh.advertise<geometry_msgs::Pose>("/slamware_ros_sdk_server_node/set_pose", 10);
  ros::Subscriber initial_pose_sub = nh.subscribe("/initialpose", 10, initialPoseCallback);

  ros::spin();

  return 0;
}