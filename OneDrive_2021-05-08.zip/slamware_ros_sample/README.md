# example of using slamware_ros_sdk

这是基于slamware_ros_sdk做的几个例程，只需要解压放置到slamware_ros_sdk同级目录编译即可使用。

目前有三个例程：
1.使用sync_get_stcm的service获取raw_stcm数据并保存到文件。
2.使用sync_set_stcm的service读取保存在文件中的raw_stcm数据并同步更新地图。
3.使用rviz上的2d pose estimate工具给定初始位姿

================================================================

These are several demos based on slamware_ros_sdk. Please unzip it and place it in the same level directory as slamware_ros_sdk. After that, you could compile and use it.

There are three demos:
1. Use sync_get_stcm service to get raw_stcm data and save it to a file.
2. Use sync_set_stcm service to read raw_stcm data saved in the file and update the map synchronously.
3. Use the 2d pose estimate tool on rviz to give the initial pose.